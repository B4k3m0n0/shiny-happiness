{{ HTML::style('css/bootstrap.min.css') }}

{{ HTML::style('css/master.css') }}

{{ HTML::style('//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css') }}

@yield('styles')