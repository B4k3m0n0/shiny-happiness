{{ HTML::script('https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js') }}

{{ HTML::script('https://ajax.googleapis.com/ajax/libs/angularjs/1.3.8/angular.min.js') }}

{{ HTML::script('js/bootstrap.min.js') }}

{{ HTML::script('js/master.js') }}

@yield('scripts')