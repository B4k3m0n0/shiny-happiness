<?php

class UsersGame extends Eloquent {

		protected $fillable = array('game_id', 'user','score');

}