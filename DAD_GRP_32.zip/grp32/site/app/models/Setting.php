<?php

class Setting extends Eloquent {

	protected $fillable = array('diceImageName', 'diceImage');
	
}
