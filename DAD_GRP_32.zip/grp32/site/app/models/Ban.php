<?php

class Ban extends Eloquent {

	protected $fillable = array('banned_user', 'reason');
	
}
